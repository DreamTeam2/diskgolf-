'''
Created on Nov 10, 2015

@author: dusky
'''


class Spravca(object):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
        raise Exception("Non implemented")
    
    def pridajUzivatela(self, uzivatelData):
        raise Exception("Non implemented")
    
    def odoberUzivatela(self, idUzivatela):
        raise Exception("Non implemented")
    
    def zmenUzivatela(self, idUzivatela, uzivatelData):
        raise Exception("Non implemented")
    
    def pridajHraca(self, hracData):
        raise Exception("Non implemented")
    
    def odoberHraca(self, idHraca):
        raise Exception("Non implemented")
    
    def zmenHraca(self, idHraca, hracData):
        raise Exception("Non implemented")
    
    def pridajTurnaj(self, turnajData):
        raise Exception("Non implemented")
    
    def odoberTurnaj(self, idTurnaja):
        raise Exception("Non implemented")
    
    def zmenTurnaj(self, idTurnaja, turnajData):
        raise Exception("Non implemented")
    
    def pridajKategoriu(self, kategoriaData):
        raise Exception("Non implemented")
    
    def odoberKategoriu(self, idKategorie):
        raise Exception("Non implemented")
    
    def zmenKategoriu(self, idKategorie, kategoriaData):
        raise Exception("Non implemented")
    
    def pridajTim(self, timData):
        raise Exception("Non implemented")
    
    def odoberTim(self, idTimu):
        raise Exception("Non implemented")
    
    def zmenTim(self, idTimu, timData):
        raise Exception("Non implemented")
    
    def pridajZapas(self, zapasData):
        raise Exception("Non implemented")
    
    def odoberZapas(self, idZapas):
        raise Exception("Non implemented")
    
    def zmenZapas(self, idZapas, zapasData):
        raise Exception("Non implemented")
    
    def pridajKlub(self, klubData):
        raise Exception("Non implemented")
    
    def odoberKlub(self, idKlubu):
        raise Exception("Non implemented")
    
    def zmenKlub(self, idKlubu, klubData):
        raise Exception("Non implemented")
    
    def pridajKategoriuTurnaju(self, kategoriaTurnajuData):
        raise Exception("Non implemented")
    
    def odoberKategoriuTurnaju(self, idKategorieTuraju):
        raise Exception("Non implemented")
    
    def zmenKategoriuTurnaju(self, idKategorieTuraju, kategoriaTurnajuData):
        raise Exception("Non implemented")
    
    def pridajHracaTimu(self, hracaTimuData):
        raise Exception("Non implemented")
    
    def odoberHracaTimu(self, idHracaTimu):
        raise Exception("Non implemented")
    
    def zmenHracaTimu(self, idHracaTimu, hracaTimuData):
        raise Exception("Non implemented")