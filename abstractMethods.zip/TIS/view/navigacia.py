'''
Created on Nov 10, 2015

@author: dusky
'''
import vykresli.Vykresli as VykresliAbstract

class Navigacia(VykresliAbstract):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
        raise Exception("Not implemented")