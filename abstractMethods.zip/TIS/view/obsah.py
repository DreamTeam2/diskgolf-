'''
Created on Nov 10, 2015

@author: dusky
'''

import vykresli.Vykresli as VykresliAbstract

class ObsahKlub(VykresliAbstract):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
        
        
class ObsahTurnaj(VykresliAbstract):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
      
    
class ObsahTim(VykresliAbstract):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
      
class ObsahHrac(VykresliAbstract):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
      
class ObsahZapas(VykresliAbstract):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''

class ObsahUzivatel(VykresliAbstract):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''

class ObsahKategorie(VykresliAbstract):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''  