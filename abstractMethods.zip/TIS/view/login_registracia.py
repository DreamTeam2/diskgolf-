'''
Created on Nov 10, 2015

@author: dusky
'''
import vykresli.Vykresli as VykresliAbstract

class Login(VykresliAbstract):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
        

class Registracia(VykresliAbstract):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
        