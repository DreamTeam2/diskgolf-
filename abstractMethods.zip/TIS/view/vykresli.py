'''
Created on Nov 10, 2015

@author: dusky
'''

class Vykresli():
    
    def __init__(self):
        pass
    
    def vykresli(self, plocha):
        raise Exception("Not implemented")
    
    def klik(self, pozicia):
        raise Exception("Not implemented")