'''
Created on Nov 10, 2015

@author: dusky
'''

class Hrac(object):
    '''
    classdocs
    '''
    idHraca = None
    idKlubu = None
    meno = None
    priezvisko = None
    prezivka = None
    fotografia = None
    poznamka = None

    def __init__(self, idHraca, idKlubu, meno, priezvisko, prezivka, fotografia = None, poznamka = None):
        '''
        Constructor
        '''
        raise Exception("Non implemented")
        