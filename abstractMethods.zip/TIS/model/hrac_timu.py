'''
Created on Nov 10, 2015

@author: dusky
'''

class HracTimu(object):
    '''
    classdocs
    '''
    idHracaTimu = None
    idHraca = None
    idTimu = None

    def __init__(self, idHracaTimu, idHraca, idTimu):
        '''
        Constructor
        '''
        raise Exception("Non implemented")
        