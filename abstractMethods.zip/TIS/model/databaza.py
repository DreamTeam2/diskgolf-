'''
Created on Nov 10, 2015

@author: dusky
'''

class Databaza(object):
    '''
    classdocs
    '''
    

    def __init__(self, params):
        '''
        Constructor
        '''
        raise Exception("Non implemented") 
    
    def pripojSaDoDatabazy(self):
        raise Exception("Non implemented")
    
    def odpojSaZDatabazy(self):
        raise Exception("Non implemented")
    
    def vyberUdaje(self, query):
        raise Exception("Non implemented")
    
    def vlozUdaje(self, query):
        raise Exception("Non implemented")
    
    def vymazUdaje(self, query):
        raise Exception("Non implemented")
    
    def zacniTranzakciu(self):
        raise Exception("Non implemented")
    
    def ukonciTranzakciu(self):
        raise Exception("Non implemented")
    
    def zistiPocet(self, table):
        raise Exception("Non implemented")