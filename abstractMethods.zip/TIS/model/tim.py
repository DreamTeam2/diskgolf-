'''
Created on Nov 10, 2015

@author: dusky
'''

class Tim(object):
    '''
    classdocs
    '''
    idTimu = None
    idTurnaju = None
    idKlubu = None
    nazov = None
    

    def __init__(self, idTimu, idTurnaju, idKlubu, nazov):
        '''
        Constructor
        '''
        raise Exception("Non implemented")
        