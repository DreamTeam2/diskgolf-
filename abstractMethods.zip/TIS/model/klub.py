'''
Created on Nov 10, 2015

@author: dusky
'''

class Klub(object):
    '''
    classdocs
    '''
    idKlubu = None
    nazov = None
    
    def __init__(self, idKlubu, nazov):
        '''
        Constructor
        '''
        raise Exception("Non implemented")
        