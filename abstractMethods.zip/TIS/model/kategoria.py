'''
Created on Nov 10, 2015

@author: dusky
'''

class Kategoria(object):
    '''
    classdocs
    '''
    idKategorie = None
    nazov = None

    def __init__(self, idKategorie, nazov):
        '''
        Constructor
        '''
        raise Exception("Non implemented")
        