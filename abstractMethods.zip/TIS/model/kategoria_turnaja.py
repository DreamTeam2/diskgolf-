'''
Created on Nov 10, 2015

@author: dusky
'''

class KategoriaTurnaju(object):
    '''
    classdocs
    '''
    idKategorieTurnaju = None
    idTurnaju = None
    idKategorie = None

    def __init__(self, idKategorieTurnaju, idTurnaju, idKategorie):
        '''
        Constructor
        '''
        raise Exception("Non implemented")
        