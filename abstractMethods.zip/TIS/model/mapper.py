'''
Created on Nov 10, 2015

@author: dusky
'''

import model.databaza.Databaza as Databaza

class Mapper(Databaza):
    '''
    classdocs
    '''
    

    def __init__(self, params):
        '''
        Constructor
        '''     
        
    def vratZoznamVsetkychUzivatelov(self):
        raise Exception("Non implemented")
    
    def vratUzivatela(self, idUzivatela):
        raise Exception("Non implemented")
    
    def vratZoznamVsetkychHracov(self):
        raise Exception("Non implemented")
    
    def vratHraca(self, idHraca):
        raise Exception("Non implemented")
    
    def vratZoznamVsetkychKlubov(self):
        raise Exception("Non implemented")
    
    def vratZoznamVsetkychHracovKlubu(self, idKlubu):
        raise Exception("Non implemented")
    
    def vratZoznamVsetkychTimovKlubu(self, idKlubu):
        raise Exception("Non implemented")
    
    def vratKlub(self, idKlubu):
        raise Exception("Non implemented")
    
    def vratZoznamVsetkychTimov(self):
        raise Exception("Non implemented")
    
    def vratZoznamVsetkychHracovTimu(self, idTimu):
        raise Exception("Non implemented")
    
    def vratTim(self, idTimu):
        raise Exception("Non implemented")
    
    def vratZoznamVsetkychHracovTimov(self):
        raise Exception("Non implemented")

    def vratHracaTimu(self, idHracaTimu):
        raise Exception("Non implemented")
    
    def vratZoznamVsetkychZapasov(self):
        raise Exception("Non implemented")
    
    def vratZoznamVsetkychZapasovTurnaju(self, idTurnaju):
        raise Exception("Non implemented")
    
    def vratZapas(self, idZapasu):
        raise Exception("Non implemented")
    
    def vratZoznamVsetkychTurnajov(self):
        raise Exception("Non implemented")
    
    def vratZoznamVsetkychTimovTurnaju(self, idTurnaju):
        raise Exception("Non implemented")
    
    def vratZoznamVsetkychKlubovTurnaju(self, idTurnaju):
        raise Exception("Non implemented")
    
    def vratTurnaj(self, idTurnaju):
        raise Exception("Non implemented")
    
    def vratZoznamVsetkychKategorii(self):
        raise Exception("Non implemented")
    
    def vratKategoriu(self, idKategorie):
        raise Exception("Non implemented")
    
    def vratZoznamVsetkychKategoria_Turnaja(self):
        raise Exception("Non implemented")
    
    def vratZoznamVsetkychKategoriiTurnaju(self, idTurnaju):
        raise Exception("Non implemented")
    
    def vratKategoria_Turnaja(self, idKategoriaTurnaja):
        raise Exception("Non implemented")
    